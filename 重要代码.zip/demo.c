#include <stdio.h>

typedef enum
{
    MSG_PASS = 0,
    MSG_STRANGER_ALERT = 1
} MsgType;

typedef struct
{
    int person_id;
    int is_stranger;
    float score;
    float x;
    float y;
    float w;
    float h;
    MsgType type;
} FaceResultMsg;

#define QUEUE_SIZE 16

typedef struct
{
    FaceResultMsg data[QUEUE_SIZE];
    int front;
    int rear;
    int count;
} FaceMsgQueue;

FaceMsgQueue normal_queue = {0};
FaceMsgQueue alert_queue = {0};

int queue_push(FaceMsgQueue *queue, FaceResultMsg msg)
{
    if (queue->count >= QUEUE_SIZE)
    {
        return -1;
    }

    queue->data[queue->rear] = msg;
    queue->rear = (queue->rear + 1) % QUEUE_SIZE;
    queue->count++;

    return 0;
}

int queue_pop(FaceMsgQueue *queue, FaceResultMsg *msg)
{
    if (queue->count <= 0)
    {
        return -1;
    }

    *msg = queue->data[queue->front];
    queue->front = (queue->front + 1) % QUEUE_SIZE;
    queue->count--;

    return 0;
}

FaceResultMsg run_kpu_face_inference(void)
{
    FaceResultMsg msg;

    msg.person_id = -1;
    msg.is_stranger = 1;
    msg.score = 0.92f;
    msg.x = 120.0f;
    msg.y = 80.0f;
    msg.w = 160.0f;
    msg.h = 160.0f;

    if (msg.is_stranger)
    {
        msg.type = MSG_STRANGER_ALERT;
    }
    else
    {
        msg.type = MSG_PASS;
    }

    return msg;
}

void push_ipc_message(FaceResultMsg msg)
{
    if (msg.type == MSG_STRANGER_ALERT)
    {
        queue_push(&alert_queue, msg);
        printf("[B_IPC] push high priority stranger alert\n");
    }
    else
    {
        queue_push(&normal_queue, msg);
        printf("[B_IPC] push normal pass message\n");
    }
}

void send_to_small_core(FaceResultMsg msg)
{
    printf("[B_TO_SMALL] person_id=%d is_stranger=%d score=%.2f bbox=(%.0f,%.0f,%.0f,%.0f)\n",
           msg.person_id,
           msg.is_stranger,
           msg.score,
           msg.x,
           msg.y,
           msg.w,
           msg.h);
}

void ipc_dispatch(void)
{
    FaceResultMsg msg;

    if (queue_pop(&alert_queue, &msg) == 0)
    {
        printf("[B_DISPATCH] handle high priority stranger alert\n");
        send_to_small_core(msg);
        return;
    }

    if (queue_pop(&normal_queue, &msg) == 0)
    {
        printf("[B_DISPATCH] handle normal pass message\n");
        send_to_small_core(msg);
        return;
    }
}

int main(void)
{
    FaceResultMsg result;

    printf("[B_AI] RT-Thread Smart big core app start\n");
    printf("[B_CAPTURE] image capture and preprocess\n");

    result = run_kpu_face_inference();

    printf("[B_KPU] face inference finished\n");
    printf("[B_RENDER] draw face box on screen\n");

    push_ipc_message(result);
    ipc_dispatch();

    return 0;
}
