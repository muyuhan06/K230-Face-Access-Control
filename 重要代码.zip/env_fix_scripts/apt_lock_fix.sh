#!/bin/bash
# 修复apt自动更新占用锁问题
sudo systemctl stop unattended-upgrades
sudo systemctl disable unattended-upgrades
sudo rm -f /var/lib/dpkg/lock-frontend /var/cache/apt/archives/lock
sudo dpkg --configure -a
echo "apt锁清理完成，可正常执行apt安装命令"