#!/bin/bash
# Docker服务启动、开机自启脚本
sudo systemctl start docker
sudo systemctl enable docker
echo "Docker服务已启动并设置开机自启"
echo "查看运行状态命令：sudo systemctl status docker"