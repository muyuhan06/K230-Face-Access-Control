#!/bin/bash
# 清理SDK dl、output、nncase缓存，用于完整重新下载AI工具
cd ~/k230_sdk
rm -rf dl output nncase_out
echo "缓存清理完成，执行 make prepare_sourcecode 即可重新下载离线包"